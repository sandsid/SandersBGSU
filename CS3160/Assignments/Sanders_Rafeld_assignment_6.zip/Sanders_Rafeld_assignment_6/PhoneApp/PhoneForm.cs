﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PhoneApp
{
    public partial class PhoneForm : Form
    {

        public Phone mNewPhone;

        public PhoneForm()
        {
            InitializeComponent();
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            try
            {
                mNewPhone = new Phone(this.txtName.Text, this.txtPhone.Text);
            }
            catch (Exception exc)
            {
                // If there's an error, just return to the form and allow
                // the user to fix the problem.
                MessageBox.Show(exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            this.DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}
