﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhoneApp
{
    public class Phone
    {
        /// <summary>
        /// There is one Phone object per phone number in the
        /// database.
        /// </summary>
        private string mFullName;
        private string mPhoneNumber;

        public Phone(string name, string phone)
        {
            // Use the properties so that data validation is done.
            Name = name;
            PhoneNumber = phone;
        }

        public string Name
        {
            get { return mFullName; }
            set
            {
                // A valid name must contain a comma.
                if (value.IndexOf(",") < 0)
                    throw new ApplicationException("Invalid name format: " + value);
                mFullName = value;
            }
        }

        public string PhoneNumber
        {
            get { return mPhoneNumber; }
            set
            {
                if (value.Length != 10)
                    throw new ApplicationException("Phone number must be ten digits: " + value);
                for (int i = 0; i < 10; ++i)
                    if (!char.IsDigit(value[i]))
                        throw new ApplicationException("Phone number must be ten digits: " + value);
                mPhoneNumber = value;
            }
        }

        public override string ToString()
        {
            return mFullName;
        }

        public override bool Equals(object obj)
        {
            Phone other;
            // Make sure we're comparing two Phone objects.
            if (obj == null || !(obj is Phone))
                return false;
            // Two Phone objects are equal if the phone numbers are
            // the same.
            other = (Phone)obj;
            return mPhoneNumber == other.PhoneNumber;
        }

        public override int GetHashCode()
        {
            // Just hash the phone number.
            return mPhoneNumber.GetHashCode();
        }
    }
}
