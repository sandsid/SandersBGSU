﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab6
{
    class MyFieldException : ApplicationException
    {
        private string errormessage;
        private string fielderror;
        private string userinput;

        public string FieldError
        {
            get { return fielderror; }
        }

        public string UserInput
        {
            get { return userinput; }
        }
        public string ErrorMessage
        {
            get { return errormessage; }
        }
        MyFieldException(string message, string error, string input)
        {
            errormessage = message;
            fielderror = error;
            userinput = input;

            FieldExceptionForm frm = new FieldExceptionForm();
        }
    }
}
