﻿Option Strict Off
Public Class Form1

    '********************************************************
    ' Purpose: This program reads in scores from a data file and stores
    ' them in an array.  It displays the values in the array in a listbox.
    ' Input: Test scores are read in from a data file.  Each test score
    '   is on a separate line.
    ' Processing: The main program calls procedures to:
    '   1. Read the scores from a file and store them in an array
    '   2. Display the values stored in the array of scores in a listbox
    ' Output: Displays a list of the scores after they are read in
    '   from the file.
    '********************************************************

    Private Sub btnGetScores_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetScores.Click
        Const MAX_SIZE As Integer = 5
        Dim names(MAX_SIZE) As String
        Dim scores(MAX_SIZE) As Integer
        Dim avgScore As Double
        Dim searchName As String
        Dim position As Integer

        ' Read in scores and store in array
        ReadScores(names, scores, MAX_SIZE)

        ' Print scores read in to list box
        lstScores.Items.Add("")
        lstScores.Items.Add("Scores")
        PrintScores(names, scores, MAX_SIZE)

        ' Find the average score
        findAvgScore(avgScore, scores, MAX_SIZE)

        lstScores.Items.Add("The average score is " & avgScore)

        ' Find student's score
        searchName = InputBox("Enter name to search for")
        findName(searchName, names, MAX_SIZE, position)

        If position = -1 Then
            lstScores.Items.Add(searchName & " not found.")
        Else
            lstScores.Items.Add(searchName & " has a score of " & scores(position))
        End If


    End Sub

    '----------------------------------------------------------
    ' This subroutine reads scores from a text file and stores
    ' them in an array.
    '----------------------------------------------------------
    Sub ReadScores(ByRef names() As String, ByRef scores() As Integer,
                   ByVal MAX_SIZE As Integer)
        Dim sr As IO.StreamReader = IO.File.OpenText("scores2.txt")
        Dim x As Integer

        'For x = 1 To MAX_SIZE
        '    names(x) = sr.ReadLine
        '    scores(x) = sr.ReadLine
        'Next

        x = 0
        Do Until sr.EndOfStream
            x = x + 1
            names(x) = sr.ReadLine
            scores(x) = sr.ReadLine
        Loop

        lstScores.Items.Add(x & " names and scores read")
        sr.Close()
    End Sub
    '----------------------------------------------------------
    ' This subroutine displays the scores stored in the array.
    '----------------------------------------------------------
    Sub PrintScores(ByRef names() As String, ByRef scores() As Integer,
                   ByVal MAX_SIZE As Integer)
        Dim k As Integer

        For k = 1 To MAX_SIZE
            lstScores.Items.Add(k & "  " & names(k) & "    " & scores(k))
        Next
    End Sub

    Sub findAvgScore(ByRef avgScore As Double, ByRef scores() As Integer,
                      ByVal MAX_SIZE As Integer)
        Dim total As Integer
        Dim x As Integer

        For x = 1 To MAX_SIZE
            total = total + scores(x)
        Next

        avgScore = total / MAX_SIZE
    End Sub

    Sub findName(ByVal searchName As String, ByRef names() As String,
                 ByVal MAX_SIZE As Integer, ByRef position As Integer)
        Dim k As Integer

        position = -1

        For k = 1 To MAX_SIZE
            If names(k) = searchName Then
                position = k
            End If
        Next
    End Sub
End Class
