﻿Public Class Form1
    Private Sub btnShowPop_Click(sender As Object, e As EventArgs) Handles btnShowPop.Click
        Dim sr As IO.StreamReader
        sr = IO.File.OpenText("lab7.txt")

        Dim cityName As String
        Dim cityPop As Double

        Do Until sr.EndOfStream
            cityName = sr.ReadLine
            cityPop = sr.ReadLine
            If cityPop >= 2 Then
                lstCityPops.Items.Add(cityName & "        " & cityPop)
            End If
        Loop

        sr.Close()

    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        End
    End Sub
End Class
