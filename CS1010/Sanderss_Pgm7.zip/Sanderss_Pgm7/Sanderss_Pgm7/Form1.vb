﻿'Sidney Sanders 
'CS 1010    12:30-1:20      12/6/17
'Input: the input comes from a text file
'purpose of the program is to have a concluding report with all storm activity in the atlantic in the past year
'Processing: once text file is read in, many subprocedures are called to find all other necessary information about the storms
'Output: the out put is everything diplayed in the list box. a sub procedure is called to show all the storm data
'   then other information within other subs are added as the code carries on. the average and the highest wind velocity
'   are a few that come in later inthe program.

Option Strict Off
Public Class Form1
    Private Sub btnStorm_Click(sender As Object, e As EventArgs) Handles btnStorm.Click

        'calling of initial variables and creating the array
        Const maxNum As Integer = 11
        Dim name(maxNum) As String
        Dim wind(maxNum) As Integer
        Dim category(maxNum) As String

        'begining of inut when sub is called to reaad in the arrays
        FindNameWind(maxNum, wind, name)
        'sub that will take wind and determine the categery and pass it back
        CategoryCheck(wind, category, maxNum)
        'sub to diplay header and storm information into the listbox
        DisplayData(name, wind, maxNum, category)
        'taaaking the wind, finding the average and them displaying it into the listbox
        AvgWind(wind, maxNum)
        'sub to determine which storm had the highest wind velocity and then displaying it into the list box.
        HighestWind(wind, name, maxNum)

    End Sub

    'sub that will open a text file to read in the information and then add it to the arrays.
    Sub FindNameWind(ByVal maxNum As Integer, ByRef wind() As Integer, ByRef name() As String)

        Dim x As Integer = 0
        Dim sr As IO.StreamReader = IO.File.OpenText("pgm7.txt")

        'loop to enter data into the array from teh text file
        Do Until sr.EndOfStream
            x = x + 1
            name(x) = sr.ReadLine
            wind(x) = sr.ReadLine
        Loop

        'closing the file of pgm7.txt
        sr.Close()
    End Sub

    'Sub that takes the data from the array in wind and runs it through an if loop, will determine which category storm it is
    Sub CategoryCheck(ByRef wind() As Integer, ByRef category() As String, ByVal maxNum As Integer)

        Dim x As Integer = 1
        For x = 1 To maxNum
            If wind(x) < 34 Then
                category(x) = "Depression"
            ElseIf wind(x) <= 63 Then
                category(x) = "Tropical Storm"
            ElseIf wind(x) <= 82 Then
                category(x) = "Hurricane 1"
            ElseIf wind(x) <= 95 Then
                category(x) = "Hurricane 2"
            ElseIf wind(x) <= 112 Then
                category(x) = "Hurricane 3"
            ElseIf wind(x) <= 135 Then
                category(x) = "Hurricane 4"
            Else
                category(x) = "Hurricane 5"
            End If
        Next

    End Sub

    'sub that will display all data so far into the listbox
    Sub DisplayData(ByVal names() As String, ByVal wind() As Integer, ByVal maxNum As Integer, ByVal category() As String)

        Dim fmtCategory As String = "{0, -10}{1, -20}{2, -20}"
        Dim fmtData As String = "{0,-15}{1,-15}{2,-20}"
        Dim x As Integer

        lstBox.Items.Add("        Atlantic Storm Activity for 2009")
        lstBox.Items.Add("                Sidney Sanders")
        lstBox.Items.Add(String.Format(fmtCategory, "Name", "Wind Velocity", "Storm Category"))
        lstBox.Items.Add("--------------------------------------------------------------------")

        For x = 1 To maxNum
            lstBox.Items.Add(String.Format(fmtData, " " & names(x), wind(x), category(x)))
        Next

    End Sub

    'taking wind, adding, finding the average then displaing the found average into the listbox
    Sub AvgWind(ByRef wind() As Integer, ByVal maxNum As Integer)

        Dim x As Integer
        Dim avg As Double

        For x = 1 To maxNum
            avg = avg + wind(x)
        Next
        avg = avg / maxNum

        lstBox.Items.Add("Average Wind velocity(knots) = " & avg)

    End Sub

    'Sub to find the highest wind velocity out of all the storms then displaying it into the list box
    Sub HighestWind(ByRef wind() As Integer, ByRef name() As String, ByVal maxNum As Integer)

        Dim x As Integer
        Dim mostWind As Integer
        Dim position As Integer = 0

        For x = 1 To maxNum
            If wind(x) > mostWind Then
                mostWind = wind(x)
                position = x
            End If
        Next

        lstBox.Items.Add("Storm " & name(position) & " had the highest wind velocity of " & wind(position) & ".")

    End Sub
End Class
