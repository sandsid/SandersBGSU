// Program 8  disk header file
// Description: Products program       
// Programmer:   Sidney Sanders  
// Class:    CS 2020 Spring 2019 


#ifndef PROG8DISK_H
#define PROG8DISK_H

using namespace std;

class Disc
{
private:
	int weight;
	Disc *pNext;
public:
	
	Disc() { weight = 0; pNext = nullptr; };
	Disc(int howMany) { weight = howMany; pNext = nullptr; };
	//~Disc();


	int getWeight() { return weight;}
	Disc* getPtr() { return pNext; }

	void setWeight(int num) { weight = num; };
	void setPointer(Disc *pointer) { pNext = pointer; };

};





#endif // !PROG8DISK_H
