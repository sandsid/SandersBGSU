// Program 8  tower cpp file
// Description: Products program       
// Programmer:   Sidney Sanders  
// Class:    CS 2020 Spring 2019 

#include "prog8tower.h"
#include "prog8disk.h"
#include <iostream>
#include <iomanip>

using namespace std;

void addDisc(Disc* &, Disc*);

string TowersOfHanoi::convert(int count)
{
	string tower;

	if (count == 1)
	{
		tower = "A";
	}
	else if (count == 2) 
	{
		tower = "B";
	}
	else
	{
		tower = "C";
	}
	return tower;
}

TowersOfHanoi::TowersOfHanoi(int count)
{
	pAhead = nullptr;

	Disc *pNew = nullptr;

	while(count != 0)
	{
		pNew = new Disc(count);
		addDisc(pAhead, pNew);
		count--;
	}
	
	
}

void TowersOfHanoi::displayTower()
{
	// displaying tower A
	Disc *pATemp = pAhead;
	cout << "A: ";
	while (pATemp != nullptr)
	{
		cout << pATemp->getWeight();

		pATemp = pATemp->getPtr();
	}
	cout << endl;
	
	//Displaying tower B
	Disc *pBTemp = pBhead;
	cout << "B:  ";
	while (pBTemp != nullptr)
	{
		cout << pBTemp->getWeight();

		pBTemp = pBTemp->getPtr();
	}
	cout << endl;

	//Display tower C
	Disc *pCTemp = pChead;
	cout << "C:  ";
	while (pCTemp != nullptr)
	{
		cout << pCTemp->getWeight();

		pCTemp = pCTemp->getPtr();
	}
	cout << endl;

	delete pATemp;
	delete pBhead;
	delete pCTemp;

	pATemp = nullptr;
	pBTemp = nullptr;
	pCTemp = nullptr;
}

void TowersOfHanoi::moveDisc(int source, int destination)
{

}

void TowersOfHanoi::moveTower(int, int, int, int)
{

}

void addDisc(Disc* &pHead, Disc* pNew) 
{
	Disc* pTemp = nullptr;

	if (pHead->getPtr() == nullptr)
	{
		pHead->setPointer(pNew);
	}
	else
	{
		pTemp = pHead;
		while (pTemp->getPtr() != nullptr)
		{
			pTemp = pTemp->getPtr();
		}
		pTemp->setPointer(pNew);
	}

	delete pTemp;
	pTemp = nullptr;
}