// Program 8  tower header file
// Description: Products program       
// Programmer:   Sidney Sanders  
// Class:    CS 2020 Spring 2019 

#ifndef PROG8TOWER_H
#define PROG8TOWER_H

using namespace std;

#include <iostream>
#include <string>
#include "prog8disk.h"


class TowersOfHanoi
{
private:
	int count;
	Disc *pAhead;
	Disc *pBhead;
	Disc *pChead;
	string convert(int);
public:
	TowersOfHanoi(int count);
	//~TowersOfHanoi();

	void displayTower();
	void moveDisc(int, int);
	void moveTower(int, int, int, int);
};




#endif