// CS2020 Program 2: program2.cpp
//
// Program 2
// Description: Employee tracking program
// Programmer: Dr. Robert Dyer
// Class: CS 2020, Summer 2019

#include<iostream>
#include<iomanip>
#include<fstream>
#include<string>

using namespace std;

//const int MAX_EMPS = 50; // program tracks at most this many employees

struct Employee {
	int    id;      // unique employee identifier
	string name;    // employee�s full name
	double rate;    // employee�s hourly rate
	double hours;   // how many hours they worked since last pay
	double taxable; // the current year�s taxable income
	Employee* next;	// pointer to next employee
};

// function prototypes
int menu();
void addEmp(Employee* &);
void addHours(Employee* &);
void printPaychecks(Employee* &);
Employee* findEmp(int, Employee*);
void removeEmployee(Employee* &);


int main()
{
	//Employee emps[MAX_EMPS];
	Employee* headPtr;
	headPtr = new Employee;
	headPtr = nullptr;



	int choice = menu();
	while (choice != 5) {
		switch (choice) {
		case 1:
			addEmp(headPtr);
			break;
		case 2:
			addHours(headPtr);
			break;
		case 3:
			printPaychecks(headPtr);
			break;
		case 4:
			removeEmployee(headPtr);
			break;
		}
		choice = menu();
	}

	return 0;
}

// Function:    menu()
// Description: displays a menu to users, asks for input, validates the input
// Parameters:  none
// Returns:     a valid menu choice
int menu() {
	int input;

	cout << "        BGSU Dining Center" << endl;
	cout << "----------------------------------" << endl;
	cout << "1. Enter new employee information" << endl;
	cout << "2. Add hours for an employee" << endl;
	cout << "3. Print paychecks" << endl;
	cout << "4. Fire Employee, print outstanding pay" << endl;
	cout << "5. Exit the program" << endl << endl;
	cout << "Select a menu option (press enter): ";
	cin >> input;

	// validate the input
	if (input < 1 || input > 5)
		return menu();

	return input;
}

// Function:    addEmp()
// Description: adds an employee
// Parameters:  emps, the array of employes
//              totalEmps, how many employees are in the array
// Returns:     nothing
void addEmp(Employee* &pHead) {
	Employee* pNew = nullptr;
	pNew = new Employee;
	Employee* pTemp = pHead;

	pNew->hours = 0.0;
	pNew->taxable = 0.0;
	cout << "Enter the new employee's ID (press enter): ";
	cin >> pNew->id;
	cout << "Enter the new employee's name: ";
	cin >> pNew->name;
	cout << "Enter the new employee's rate (press enter): ";
	cin >> pNew->rate;

	pNew->next = nullptr;

	if (pHead == nullptr)
		pHead = pNew;
	else //inserting node at end of list
	{
		//find last node
		while (pTemp->next)
			pTemp = pTemp->next;

		//insert node at end
		pTemp->next = pNew;
	}
}

// Function:    addHours()
// Description: adds hours to an employee
// Parameters:  emps, the array of employes
//              totalEmps, how many employees are in the array
// Returns:     nothing
void addHours(Employee* &pHead) {

	int id;
	cout << "Enter the employee's ID to add hours to (press enter): ";
	cin >> id;

	Employee* pos = findEmp(id, pHead);
	if (pos == nullptr) {
		cout << "Invalid employee ID!" << endl;
		return;
	}

	double hours;
	cout << "Add how many hours? (press enter): ";
	cin >> hours;
	pos->hours += hours;
}

// Function:    printPaychecks()
// Description: prints paychecks for employees,
//              updating taxable income for the year,
//              and resets their hours back to 0
// Parameters:  emps, the array of employes
//              totalEmps, how many employees are in the array
// Returns:     nothing
void printPaychecks(Employee* &pHead) {
	cout << setw(6) << "ID |"
		<< setw(12) << "Name |"
		<< setw(9) << "Rate |"
		<< setw(10) << "Paycheck" << endl;
	cout << "-----+-----------+--------+----------" << endl;

	Employee* pTemp = pHead;

	while (pTemp != nullptr) {
		if (pTemp->hours > 0.0) {
			cout << setw(4) << pTemp->id << " |"
				<< setw(10) << pTemp->name << " |"
				<< setw(7) << fixed << setprecision(2) << pTemp->rate << " |"
				<< setw(10) << setprecision(2) << (pTemp->rate * pTemp->hours) << endl;
			pTemp->taxable += (pTemp->rate * pTemp->hours);
			pTemp->hours = 0.0;
			pTemp = pTemp->next;
		}
	}

	cout << endl;
}

// Function:    findEmp()
// Description: attempts to locate an employee by id
// Parameters:  target, the target employee id
//              emps, the array of employes
//              totalEmps, how many employees are in the array
// Returns:     -1 if not found, otherwise the index of the matching employee
Employee* findEmp(int target, Employee* pHead) {
	Employee* pTemp = pHead;

	//traverse through list
	if (!pTemp)
		return nullptr;

	while (pTemp->next) {
		if (pTemp->id == target)
		{
			return pTemp;
		}
		pTemp = pTemp->next;
	}
	if (pTemp->id == target)
	{
		return pTemp;
	}

	return nullptr;
}

void removeEmployee(Employee* &pHead)
{
	int target = 0;
	Employee* pos = new Employee;
	Employee* pPrev = nullptr;
	Employee* pTemp = pHead;


	cout << "Enter Id of Employee to fire: ";
	cin >> target;
	cout << endl;

	pos = findEmp(target, pHead);

	if (pos == nullptr)
	{
		cout << "Invalid employee ID." << endl;
		return;
	}
	else 
	{
		cout << setw(10) << pos->name << "'s outstanding pay:  "
			<< setw(10) << setprecision(2) << (pos->rate * pos->hours) << endl;

		if (pTemp->id == target)
		{
			//delete first node
			pHead = pHead->next;
			delete pTemp;
		}
		else
		{
			//skip all nodes whoes data is not target
			while (pTemp != nullptr && pTemp->id != target)
			{
				pPrev = pTemp;
				pTemp = pTemp->next;
			}
			//if ptemp is not the end of list
			//link prev node to node after ptemp then delete
			if (pTemp)
			{
				if (pTemp->next == nullptr)
					pPrev->next = nullptr;

				pPrev->next = pTemp->next;
				delete pTemp;


			}
		}
	}

}
