//************************************************************************
//Prog 2		The BGSU Dining Center 
//				
//Discription	� Design, implement, and use a C++ structure data type 
//				� Practice using arrays with structs 
//				� Practice with functions, menus 
//				� Practice debugging
//
//Programmer	Sidney Sanders
//Class			CS 2020 summer 2019
//************************************************************************



#include <iostream>
#include <iomanip>
#include <string>

using namespace std;


//structer ADT
struct Employee {
	int    id;      // unique employee identifier     
	string name;    // employee�s full name     
	double rate;    // employee�s hourly rate     
	double hours;   // how many hours they worked since last pay     
	double taxable; // the current year�s taxable income 
}; 

int const MAXLIST = 50;

//function declaration
int menu();
int addEmp(Employee [],int);
void addHours(Employee [], int);
void printPayChecks(Employee [], int);
int findEmp(int, Employee [], int);


int main()
{
	Employee empData[MAXLIST];
	int numChoice;
	int currentEmp = 0;

	numChoice = menu(); 
	do {
		if (numChoice == 4)
		{
			system("pause");
			return 0;
		}
		else if (numChoice == 1)
		{
			currentEmp = addEmp(empData, currentEmp);
		}
		else if (numChoice == 2)
		{
			addHours(empData, currentEmp);
		}
		else if (numChoice == 3)
		{
			printPayChecks(empData, currentEmp);
		}

		numChoice = menu();
	} while (numChoice != 4);

	system("pause");
	return 0;
}

//***********************************************************************
//Function:		Menu
//
//Purpose:		give user options for employee data
//Programmer:	Sidney Sanders
//Class:		cs 2020 summer 2019
//Parameter:	None
//Return:		Valid Number 1-4
//***********************************************************************
int menu()
{
	int numChoice;
	bool validChoice = false;
	
	cout << endl;
	cout << std::right << setw(10) << "Menu of Choices" << endl;
	cout << "++++++++++++++++++++++++++++++++++++++" << endl;
	cout << "1. Enter new Employee Information" << endl;
	cout << "2. Add Employee Hours" << endl;
	cout << "3. Display Employee Paychecks" << endl;
	cout << "4. Exit the program" << endl;

	do
	{
		cout << "Enter  Valid Number Choice:   ";
		cin >> numChoice;

	} while (numChoice < 1 || numChoice > 4);

	return numChoice;
}

//***********************************************************************
//Function:		AddEmp
//
//Purpose:		add a employee and add to amount of employees
//Programmer:	Sidney Sanders
//Class:		cs 2020 summer 2019
//Parameter:	empData array and current employee amount
//Return:		the new employee total 
//***********************************************************************
int addEmp(Employee empData[], int currentEmp)
{
	if (currentEmp >= MAXLIST)
	{
		cout << endl << "Max Employee Amount Reached" << endl;
		return currentEmp;
	}
	else
	{
		do {
			cout << "Enter Employee ID:           ";
			cin >> empData[currentEmp].id;
			for (int i = 0; i < currentEmp; i++) {
				if (empData[currentEmp].id == empData[i].id)
				{
					empData[currentEmp].id = -1;
					cout << "ID must be unique." << endl;
				}
			}
		} while (empData[currentEmp].id < 0);
		
		cout << "Enter Employee Name:         ";
		cin.ignore();
		getline(cin, empData[currentEmp].name);

		do {
			cout << "Enter Employee hourly Rate:  ";
			cin >> empData[currentEmp].rate;
		} while (empData[currentEmp].rate < 0);
		
		empData[currentEmp].hours = 0;
		empData[currentEmp].taxable = 0;
		return currentEmp;
	}
	currentEmp++;
}

//***********************************************************************
//Function:		AddHours
//
//Purpose:		update employee hours
//Programmer:	Sidney Sanders
//Class:		cs 2020 summer 2019
//Parameter:	empData array and current employee amount
//Return:		None
//***********************************************************************
void addHours(Employee empData[], int currentEmp)
{
	int pos;
	int empID;

	cout << endl << "Enter Employee ID to add/edit hours:  ";
	cin >> empID;

	pos = findEmp(empID, empData, currentEmp);
	if (pos != -1)
	{
		cout << "Enter hours for " << empData[pos].name << " :  ";
		cin >> empData[pos].hours;
	}
}

//***********************************************************************
//Function:		FindEmp
//
//Purpose:		search array of employees and pass pack position
//Programmer:	Sidney Sanders
//Class:		cs 2020 summer 2019
//Parameter:	cempData array, current employee amount and id to find
//Return:		position where customer is in array
//***********************************************************************
int findEmp(int idToFind, Employee empData[], int currentEmp)
{
	int position = -1;
	bool found = false;
	int count = 0;

	while (found == false)
	{
		found = true;
		if (count > currentEmp)
		{
			cout << endl << "No employee found" << endl;
			return -1;
		}
		else if (idToFind == empData[count].id)
		{
			position = count;
		}
		else
		{
			found = false;
			count++;
		}
	}
	return position;
}

//***********************************************************************
//Function:		PrintPaychecks 
//
//Purpose:		display list of employees in array
//Programmer:	Sidney Sanders
//Class:		cs 2020 summer 2019
//Parameter:	empData array and current employee amount
//Return:		None
//***********************************************************************
void printPayChecks(Employee empData[], int currentEmp)
{
	cout << endl << "List of all Employees:" << endl;
	cout << "******************************************" << endl;
	cout << fixed << showpoint << setprecision(2);

	for (int count = 0; count < currentEmp; count++)
	{
		//empData[count].taxable = empData[count].hours * empData[count].rate;

		cout << empData[count].id << setw(5) << empData[count].name << setw(15)
			<< empData[count].hours << setw(10) << "$" << empData[count].taxable << endl;
	
		empData[count].hours = 0;
	}
	//sometimes it prints and sometimes it doesnt idk why
}