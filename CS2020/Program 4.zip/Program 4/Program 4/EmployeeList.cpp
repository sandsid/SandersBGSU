// CS2020 Program 4: EmployeeList.cpp
//
// Program 4
// Description: Employee tracking program, with updates
// Programmer: Dr. Robert Dyer
// Class: CS 2020, Summer 2019


#include "EmployeeList.h"
#include <iostream>
#include <iomanip>

using namespace std;

// Function:    Employee constructor 
// Description:  constructor
// Parameters:  null 
// Returns:     null 
inline EmployeeList::EmployeeList()
{
	length = 0;
	pHead = nullptr;
}

// Function:    getNumberOfEmployees 
// Description: return the current number of employees 
// Parameters:  null 
// Returns:     length 
int EmployeeList::getNumberOfEmployees()
{
	return length;
}


// Function:    addEmployee 
// Description: add employee to back of list 
// Parameters:  pointer to new employee 
// Returns:     null 
inline void EmployeeList::addEmployee(Employee * newE)
{
	Employee *pTemp = pHead;
	if (pTemp == nullptr)
	{
		pHead = newE;
		length = 1;
	}
	else
	{
		while (pTemp->next)
			pTemp = pTemp->next;

		pTemp->next = newE;
		length++;
	}

}


// Function:    removeEmployee 
// Description: use a target to delete a employee  
// Parameters:  pointer to employee to delete 
// Returns:     null 
inline void EmployeeList::removeEmployee(Employee * target)
{
	Employee * pTemp = pHead;
	Employee* pos = findEmployee(target->id);
	Employee* pPrev = nullptr;



	if (pos == nullptr)
		return;
	else
	{
		if (pTemp->id == target->id)
		{
			//delete first node
			pHead = pHead->next;
			delete pTemp;
			length--;
		}
		else
		{
			//skip all nodes whoes data is not target
			while (pTemp != nullptr && pTemp->id != target->id)
			{
				pPrev = pTemp;
				pTemp = pTemp->next;
			}
			//link prev node to node after ptemp then delete
			if (pTemp)
			{
				if (pTemp->next == nullptr)
					pPrev->next = nullptr;

				pPrev->next = pTemp->next;
				delete pTemp;
				length--;
			}
		}
	}

}

// Function:    findEmploye 
// Description: find an employee in the list  
// Parameters:  id number to find 
// Returns:     the position or nullptr 
inline Employee * EmployeeList::findEmployee(int target)
{
	Employee * pTemp = pHead;
	
	if (!pTemp)
		return nullptr;

	while (pTemp->next)
	{
		if (pTemp->id == target)
		{
			return pTemp;
		}
		pTemp = pTemp->next;
	}
	if (pTemp->id == target)
	{
		return pTemp;
	}

	return nullptr;
}

// Function:    Function name 
// Description: Function purpose 
// Parameters:  list and describe 
// Returns:     describe 
inline void EmployeeList::printPaychecks()
{
	cout << setw(6) << "ID |"
		<< setw(12) << "Name |"
		<< setw(9) << "Rate |"
		<< setw(10) << "Paycheck" << endl;
	cout << "-----+-----------+--------+----------" << endl;

	Employee* pTemp = pHead;

	while (pTemp != nullptr) {
		if (pTemp->hours > 0.0) {
			cout << setw(4) << pTemp->id << " |"
				<< setw(10) << pTemp->name << " |"
				<< setw(7) << fixed << setprecision(2) << pTemp->rate << " |"
				<< setw(10) << setprecision(2) << (pTemp->rate * pTemp->hours) << endl;
			pTemp->taxable += (pTemp->rate * pTemp->hours);
			pTemp->hours = 0.0;
			pTemp = pTemp->next;
		}
	}

	cout << endl;
}


// Function:    Function name 
// Description: Function purpose 
// Parameters:  list and describe 
// Returns:     describe 
inline EmployeeList::~EmployeeList()
{

}

