// CS2020 Program 4: program4.cpp
//
// Program 4
// Description: Employee tracking program, with updates
// Programmer: Dr. Robert Dyer
// Class: CS 2020, Summer 2019

#include<iostream>
#include<iomanip>
#include<string>

#include "EmployeeList.h"

using namespace std;

// function prototypes
int menu();
void addEmp(EmployeeList*);
void removeEmp(EmployeeList*);
void addHours(EmployeeList*);


int main() {
	EmployeeList *list = new EmployeeList;

	int choice = menu();
	while (choice != 6) {
		switch (choice) {
		case 1:
			addEmp(list);
			break;
		case 2:
			addHours(list);
			break;
		case 3:
			list->printPaychecks();
			break;
		case 4:
			removeEmp(list);
			break;
		case 5:
			cout << "Number of employees: " << list->getNumberOfEmployees() << endl;
			break;
		}
		choice = menu();
	}

	delete list;

	return 0;
}

// Function:    menu()
// Description: displays a menu to users, asks for input, validates the input
// Parameters:  none
// Returns:     a valid menu choice
int menu() {
	int input;

	cout << "        BGSU Dining Center" << endl;
	cout << "----------------------------------" << endl;
	cout << "1. Enter new employee information" << endl;
	cout << "2. Add hours for an employee" << endl;
	cout << "3. Print paychecks" << endl;
	cout << "4. Remove employee" << endl;
	cout << "5. List number of employees" << endl;
	cout << "6. Exit the program" << endl
		<< endl;
	cout << "Select a menu option (press enter): ";
	cin >> input;

	// validate the input
	if (input < 1 || input > 6)
		return menu();

	return input;
}

// Function:    addEmp()
// Description: adds an employee
// Parameters:  headPtr, the list of employees
// Returns:     nothing
void addEmp(EmployeeList *list) {
	Employee *e = new Employee;
	e->hours = 0.0;
	e->taxable = 0.0;

	e->id = -1;
	while (e->id == -1) {
		cout << "Enter the new employee's ID (press enter): ";
		cin >> e->id;
		if (e->id < 1) {
			cout << "Error: employee ID's must be positive numbers." << endl;
			e->id = -1;
		}
		else {
			Employee *temp = list->findEmployee(e->id);
			if (temp != nullptr) {
				cout << "Error: an employee with that ID already exists." << endl;
				e->id = -1;
			}
		}
	}
	cout << "Enter the new employee's name: ";
	cin >> e->name;
	e->rate = 0.0;
	while (e->rate <= 0.0) {
		cout << "Enter the new employee's rate (press enter): ";
		cin >> e->rate;
		if (e->rate <= 0.0) {
			cout << "Error: an employee's rate must be more than 0." << endl;
		}
	}

	list->addEmployee(e);
}

// Function:    removeEmp()
// Description: removes an employee
// Parameters:  headPtr, the list of employees
// Returns:     nothing
void removeEmp(EmployeeList *list) {
	int id;
	cout << "Enter the employee's ID to remove (press enter): ";
	cin >> id;

	Employee *cur = list->findEmployee(id);

	if (cur == nullptr) {
		cout << "Invalid employee ID!" << endl;
	}
	else {
		cout << "Removing employee: " << cur->name << endl;
		cout << "Outstanding pay: " << setprecision(2) << (cur->rate * cur->hours) << endl;

		list->removeEmployee(cur);
	}
}

// Function:    addHours()
// Description: adds hours to an employee
// Parameters:  headPtr, the list of employees
// Returns:     nothing
void addHours(EmployeeList *list) {
	int id;
	cout << "Enter the employee's ID to add hours to (press enter): ";
	cin >> id;

	Employee *temp = list->findEmployee(id);
	if (temp == nullptr) {
		cout << "Invalid employee ID!" << endl;
		return;
	}

	double hours;
	cout << "Add how many hours? (press enter): ";
	cin >> hours;
	temp->hours += hours;
}
