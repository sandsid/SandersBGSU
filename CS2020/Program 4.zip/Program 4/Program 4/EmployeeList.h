// CS2020 Program 4: EmployeeList.h
//
// Program 4
// Description: Employee tracking program, with updates
// Programmer: Dr. Robert Dyer
// Class: CS 2020, Summer 2019

#ifndef EMPLOYEELISTS_H
#define EMPLOYEELITS_H

#include <string>


struct Employee
{
	int    id;      // unique employee identifier     
	string name;    // employee�s full name     
	double rate;    // employee�s hourly rate     
	double hours;   // how many hours they worked since last pay     
	double taxable; // the current year�s taxable income 

	Employee* next; // pointer to the next node in linked list }; 
};


class EmployeeList
{
private:
	Employee* pHead;
	int length;
public:
	int getNumberOfEmployees();
	void addEmployee(Employee*);
	void removeEmployee(Employee*);
	Employee* findEmployee(int);
	void printPaychecks();

	EmployeeList();
	~EmployeeList();
};


#endif // !EMPLOYEELISTS_H

