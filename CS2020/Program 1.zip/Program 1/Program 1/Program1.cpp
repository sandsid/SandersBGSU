//********************************************************************************
//			Programming Assignment 1
//Review:	array sorting & searching, parallel arrays
//			Practice with functions, files, and I/O
//			Practice debugging
//			Submitting program solutions to Canvas

//SIDNEY SANDERS		7/18/2019
//********************************************************************************

#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>

using namespace std;

int const MAX_AMT = 30;

//funcation declaration 
int ReadData(string[], string[], int[], double[]);
void SortArrays(string[], string[], int[], double[], int);
void PrintArrays(string[], string[], int[], double[], int);
int SearchHighestPrice(double[], int);
double ComputeTotal(string, string[], int[], double[], int);


int main() {
	string iName[MAX_AMT];      //name array
	string iLocation[MAX_AMT];  //location array
	int iQty[MAX_AMT];          //quantity array
	double iPrice[MAX_AMT];     //price array
	
	
	//variables used
	int iCount;					//count of items read in
	int highest;				//integer holding position
	double compLocation;		//location to be computed

	iCount = ReadData(iName, iLocation, iQty, iPrice);

	SortArrays(iName, iLocation, iQty, iPrice, iCount);
	PrintArrays(iName, iLocation, iQty, iPrice, iCount);
	highest = SearchHighestPrice(iPrice, iCount);

	cout << endl << "The highest priced product is the" << iName[highest] << " located in " << iLocation[highest] << " with a price of $" << iPrice[highest] << endl;

	compLocation = ComputeTotal("Romulus, MI", iLocation, iQty, iPrice, iCount);
	cout << endl << "Romulus, MI total:  " << compLocation << endl;

	compLocation = ComputeTotal("Columbus, OH", iLocation, iQty, iPrice, iCount);
	cout << endl << "Columbus, OH total:  " << compLocation << endl;

	compLocation = ComputeTotal("Euclid, OH", iLocation, iQty, iPrice, iCount);
	cout << endl << "Euclid, OH total:  " << compLocation << endl;



	system("pause");
	return 0;
}



//********************************************************************************
// name				ReadData
//
// task:			open txt file and read data into arrays  
// data in:			txt file
// data returned:	count of elements 
//
//********************************************************************************

int ReadData(string name[], string location[], int qty[], double price[])
{
	
	int pos = 0;

	ifstream infile;
	infile.open("amazonData.txt");

	if (!infile.is_open()) {
		cout << "Failed to open file" << endl;
	}
	else {
		while (!infile.eof()) {
			getline(infile, location[pos]);
			getline(infile, name[pos]);
			infile >> qty[pos];
			infile >> price[pos];
			infile.ignore();
			pos++;
		};
	}
	infile.close();

	return pos;
}


//********************************************************************************
// name				SortArrays
//
// task:			using a selection sort 
// data in:			4 arrays and the count 
// data returned:	no return for a void function
//
//********************************************************************************


void SortArrays(string name[], string location[], int qty[], double price[], int count) 
{
	//using selection sorting to sort arrays in decending order
	int seek;
	int minCount;
	int qtyTemp;
	string nameTemp, locTemp;
	double priceTemp;

	for (seek = 0; seek < (count - 1); seek++)
	{

		minCount = seek;
		qtyTemp = qty[seek];
		nameTemp = name[seek];
		locTemp = location[seek];
		priceTemp = price[seek];

		for (int index = seek + 1; index < count; index++)
		{

			if (qty[index] > qtyTemp)
			{
				qtyTemp = qty[index];
				nameTemp = name[index];
				locTemp = location[index];
				priceTemp = price[index];
				minCount = index;
			}

		}
		qty[minCount] = qty[seek];
		qty[seek] = qtyTemp;
		name[minCount] = name[seek];
		name[seek] = nameTemp;
		location[minCount] = location[seek];
		location[seek] = locTemp;
		price[minCount] = price[seek];
		price[seek] = priceTemp;
	}

}

//********************************************************************************
// name				PrintArrays
//
// task:			print arrays in list format
// data in:			4 arrrays and count	
// data returned:	no return for a void function
//
//********************************************************************************


void PrintArrays(string name[], string location[], int qty[], double price[], int elAmt) 
{

	cout << "Location          Product         Qty        Price" << endl;
	cout << "---------------------------------------------------" << endl;

	for (int count = 0; count < elAmt; count++) 
	{
		cout << setprecision(2) << fixed << setw(18) << std::left << location[count] << setw(16) << name[count] << setw(11) << qty[count]  << "$" << price[count] << endl;
	}


}

//********************************************************************************
// name				SearchHighestPrice
//
// task:			search price array to find highest priced item
// data in:			price array and count
// data returned:	return location of highest priced item
//
//********************************************************************************


int SearchHighestPrice(double price[], int elAmt)
{
	double highest;
	int pos;

	highest = price[0];

	for (int count = 0; count < elAmt; count++)
	{
		if (price[count] > highest) {
			pos = count;
			highest = price[count];
		}
	}


	return pos;
}


//********************************************************************************
// name				ComputeTotal
//
// task:			take a location, find all items for location, compute total
//					by multiplying the total qty by the price
// data in:			location, location array, qty array, price array count
// data returned:	total amount for each location
//
//********************************************************************************

double ComputeTotal(string input, string location[], int qty[], double price[], int elAmt) 
{
	double total = 0.0;	

	for (int count = 0; count < elAmt; count++)
	{
		if (input == location[count])
		{
			total = total + (qty[count] * price[count]);
		}
	}


	return total;
}


